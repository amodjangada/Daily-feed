Store each published report as a complete HTML file in this folder. See the root README for how to add it to reports.json.
