# My Daily Feed — GitHub Pages

A clean, phone-friendly home page and archive for daily learning reports.

## Publish the site

1. Open your `Daily-feed` repository on GitHub.
2. Use **Add file → Upload files** to upload `index.html`, `style.css`, `app.js`, `reports.json` and `.nojekyll` from this package. Commit the upload to `main`. The `articles` folder is optional at first.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, **main**, **/(root)**, then **Save**.
5. After GitHub finishes publishing, open `https://amodjangada.github.io/Daily-feed/`.

## Publish each new report

1. Save the full report as an HTML file such as `articles/2026-10-14-ai-learning.html`.
2. Add the file to your GitHub repository at the same path.
3. Edit `reports.json` to add an entry inside the array:

```json
[
  {
    "date": "2026-10-14",
    "title": "Example report title",
    "topic": "Technology",
    "summary": "A short description of the report.",
    "url": "articles/2026-10-14-ai-learning.html"
  }
]
```

Keep the newest entries first if editing by hand. The website also sorts by date. Reports should be genuine, complete HTML documents and have their own reading styles. Remove the sample entry above if no such report exists.

**Important:** The site does not automatically pull material from ChatGPT. Daily reports require a separate publishing step or a properly authorized publishing automation.
